create function v_annonce_parm(parm1 text)
  returns TABLE(annonce_id integer, date_annonce timestamp without time zone, categorie text, titre_annonce text, type_annonce text, discription_annonce text, prix money, specification text, titre_articl text, cours_id text, nom_annonceur text, contact_annonceur text)
language sql
as $$
select distinct ad.ad_id annonce_id, ad.DATE_TIME_AD "Date annonce",item.iteme_name categorie, ad.title "Titre d annonce",
                ad_type.type_ad "type d annonce", ad.discription_ad discription_annonce,
                ad.price prix,
                specification.specification_name,ad_specification.specification_value "Titre d article",cours.cours_id,
                student.user_name "mon annonceur", student.e_mail "contact annaonceur"

from   student, ad, item, ad_specification , ad_type, category ,ad_cours, cours, branch, specification

where  ad.ad_id= ad_specification.ad_id and ad.item_id = item.item_id and student.cip=ad.cip
  and specification.specification_id = ad_specification.specification_id and  specification.item_id=item.item_id
  and ad_cours.cours_id = cours.cours_id  and item.category_id = category.category_id
  and ad.ad_id=ad_cours.ad_id and cours.branch_id = branch.branch_id
  and ad_type.type_ad_id = ad.type_ad_id
  and specification.specification_name='titre'
  and cours.cours_id = $1

order  by  ad.DATE_TIME_AD DESC

$$;

alter function v_annonce_parm(text)
  owner to s3infoe04;

