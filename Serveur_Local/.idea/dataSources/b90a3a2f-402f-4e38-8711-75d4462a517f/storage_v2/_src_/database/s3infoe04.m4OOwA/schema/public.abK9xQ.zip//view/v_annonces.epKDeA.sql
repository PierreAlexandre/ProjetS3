create view v_annonces as
  SELECT DISTINCT ad.ad_id                             AS annonce_id,
                  ad.date_time_ad                      AS date_annonce,
                  item.item_name                       AS categorie,
                  ad.title                             AS titre_annonce,
                  ad_type.type_ad                      AS type_annonce,
                  ad.description_ad                    AS description,
                  ad.price                             AS prix,
                  specification.specification_name,
                  ad_specification.specification_value AS nom_article,
                  course.course_id,
                  student.user_name                    AS nom_annonceur,
                  student.e_mail                       AS contact_annonceur
  FROM student,
       ad,
       item,
       ad_specification,
       ad_type,
       category,
       ad_course,
       course,
       branch,
       specification
  WHERE ((ad.ad_id = ad_specification.ad_id) AND (ad.item_id = item.item_id) AND (student.cip = ad.cip) AND
         (specification.specification_id = ad_specification.specification_id) AND
         (specification.item_id = item.item_id) AND (ad_course.course_id = course.course_id) AND
         (item.category_id = category.category_id) AND (ad.ad_id = ad_course.ad_id) AND
         (course.branch_id = branch.branch_id) AND (ad_type.type_ad_id = ad.type_ad_id) AND
         (specification.specification_name = 'titre' :: text))
  ORDER BY ad.date_time_ad DESC;

alter table v_annonces
  owner to s3infoe04;

